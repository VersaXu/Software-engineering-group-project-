import imageio
import numpy as np
import cv2

np.set_printoptions(threshold=np.inf)
np.set_printoptions(linewidth=7000)
from PIL import Image


def process(x, scale):
    global height
    global width
    v_block = 0
    count = 0
    # 遍历每一个block
    while (v_block) * scale < height:
        h_block = 0
        while (h_block) * scale < width:
            # 列
            for i in range(v_block * scale, min((v_block + 1) * scale, height)):
                # 行
                for j in range(h_block * scale, min((h_block + 1) * scale, width)):
                    if x[i][j] >= 255:
                        x[i][j] -= 255
                        count += 1

            if count > (scale * scale) // 2:
                mosaic(x, v_block, h_block, scale)
            count = 0
            h_block += 1
        v_block += 1

    print("---------------------------------------------------------------------------------------------------------------")
    print(x)
    return x


def mosaic(x, v_block, h_block, scale):
    global height
    global width
    sum = 0
    count = 0
    for i in range(v_block * scale, min((v_block + 1) * scale, height)):
        for j in range(h_block * scale, min((h_block + 1) * scale, width)):
            sum += x[i][j]
            count += 1
    result = sum // count
    for i in range(v_block * scale, min((v_block + 1) * scale, height)):
        for j in range(h_block * scale, min((h_block + 1) * scale, width)):
            x[i][j] = result


scale = 25
x = cv2.imread('./static/pic/original.png')
x = np.asarray(x)
# print(x)
# print(x.shape)

area = cv2.imread('area.png')
area = np.asarray(area)  # change to int
area_b, area_g, area_r = cv2.split(area)
for i in range(900):
    for j in range(900):
        area_b[i][j] +=2
#
# global height
# global width
# height = x.shape[1]
# width = x.shape[0]
#
# x_r, x_g, x_b = cv2.split(x)
# area_b, area_g, area_r = cv2.split(area)
# # print(area.reshape(height, -1))
# #
# # # print(x)
# # x = x.reshape(-1, 3)
# # area = area.reshape(-1, 3)
# #
# # area_r, area_g, area_b = np.hsplit(area, 3)
# # area_r = area_r.reshape(height, -1)
# # print("---------------------------------------------------------------------------------------------------------------")
# # print(area_r)
# # x_r, x_g, x_b = np.hsplit(x, 3)
# # x_r = x_r.reshape(height, -1)
# # x_g = x_g.reshape(height, -1)
# # x_b = x_b.reshape(height, -1)
# # print("---------------------------------------------------------------------------------------------------------------")
# # print(x_r)
# # print("---------------------------------------------------------------------------------------------------------------")
# # print(x_g)
# # print("---------------------------------------------------------------------------------------------------------------")
# # # print(x_b)
# r = process(x_r+area_r, scale)
# g = process(x_g+area_g, scale)
# b = process(x_b+area_b, scale)
# img = cv2.merge([r, g, b])
# print(img)
# img = img.astype(np.uint8)
# cv2.imshow('image', img)
# k = cv2.waitKey(0) & 0xFF # 32位的电脑该命令为 k = cv2.waitKey(0)
#
# cv2.imwrite('output.png', img)
# if k == 27:         # wait for ESC key to exit
#     cv2.destroyAllWindows()
